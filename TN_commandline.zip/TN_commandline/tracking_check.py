import requests
import json
import os
from requests.auth import HTTPBasicAuth
from datetime import datetime, timedelta, UTC
import sys

CONFIG_FILE = 'tracking_config.json'
LAST_CHECKED_FILE = 'last_checked.json'
POST_LOG_FILE = 'ctm_post_log.json'
REQUIRED_KEYS = [
    'CTM_ACCOUNT_ID',
    'CTM_ACCESS_KEY',
    'CTM_SECRET_KEY',
    'IPQS_API_KEY'
]

def load_or_prompt_config():
    config = {}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            try:
                config = json.load(f)
            except Exception:
                pass
    updated = False
    for key in REQUIRED_KEYS:
        if not config.get(key):
            value = input(f"Enter {key}: ").strip()
            while not value:
                value = input(f"{key} is required, enter {key}: ").strip()
            config[key] = value
            updated = True
    if updated:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        print(f"Configuration saved to {CONFIG_FILE}")
    return config

def load_last_checked():
    if os.path.exists(LAST_CHECKED_FILE):
        try:
            with open(LAST_CHECKED_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_last_checked(last_checked):
    with open(LAST_CHECKED_FILE, 'w') as f:
        json.dump(last_checked, f, indent=2)

def load_post_log():
    if os.path.exists(POST_LOG_FILE):
        try:
            with open(POST_LOG_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_post_log(post_log):
    with open(POST_LOG_FILE, 'w') as f:
        json.dump(post_log, f, indent=2)

def is_over_24_hours_ago(timestr):
    try:
        last_time = datetime.strptime(timestr, '%Y-%m-%d %H:%M').replace(tzinfo=UTC)
    except Exception:
        return True
    return datetime.now(UTC) - last_time > timedelta(hours=24)

def build_ctm_update_payload(ipqs_json, checked_datetime):
    fraud_score = ipqs_json.get('fraud_score')
    spammer    = ipqs_json.get('spammer', False)
    leaked     = ipqs_json.get('leaked', False)
    risky_flag = ipqs_json.get('risky', False)
    custom_fields = {
        'TN_Risk_Fraud_Last_Checked': checked_datetime,
        'TN_Fraud_Score_over_90': bool(fraud_score is not None and int(fraud_score) > 90),
        'TN_flagged_as_spammer': bool(spammer),
        'TN_found_in_leaked_DB': bool(leaked),
        'TN_flagged_as_risky': bool(risky_flag)
    }
    return custom_fields

def write_html_report(results, account_id, output_file="tracking_check_output.html"):
    #--- Summarize
    total = len(results)
    fraud_90 = sum(r.get('fraud_score', 0) > 90 for r in results)
    spammer = sum(r.get('spammer') for r in results)
    leaked  = sum(r.get('leaked') for r in results)
    risky   = sum(r.get('risky') for r in results)
    posted  = sum(r.get('posted_to_ctm') for r in results)

    html = '''<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Tracking Numbers Risk Check</title>
<style>
:root{{--sky:#01BDF6;--nebula:#0796CA;--lime:#D6DA01;--ink:#0b1120;--muted:#94a3b8;--paper:#f8fafc;}}
body{{background:var(--ink);color:var(--paper);font-family: 'Space Grotesk', sans-serif;margin:0;}}
.wrap{{max-width:1100px;margin:0 auto;padding:22px;}}
.card{{background:rgba(15,23,42,.65);border-radius:16px;padding:16px 22px;margin-bottom:18px;box-shadow:0 10px 24px rgba(2,6,23,.22);}}
.kpi-grid{{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:14px;margin:24px 0;}}
.kpi{{background:rgba(15,23,42,.8);border-radius:14px;padding:14px;text-align:center;}}
.kpi .label{{color:var(--muted);font-size:13px;}}
.kpi .value{{font-size:19px;font-weight:800;margin-top:2px;}}
table{{width:100%;border-collapse:collapse;margin-top:12px;}}
th,td{{padding:8px 10px;text-align:left;}}
th{{background:rgba(1,189,246,.13);color:var(--sky);}}
tr:nth-child(even){{background:rgba(148,163,184,.05);}}
tr:hover{{background:rgba(1,189,246,.09);}}
.flag-yes{{color:#D6DA01;font-weight:600;}}
.flag-no{{color:var(--muted);}}
.status-yes{{color:#34d399;font-weight:600;}}
.status-no{{color:#f87171;font-weight:600;}}
@media(max-width:900px){{.kpi-grid{{grid-template-columns:repeat(2,1fr);}}}}
@media(max-width:650px){{.kpi-grid{{grid-template-columns:1fr;}}}}
</style>
</head>
<body>
<div class="wrap">
<h1 style="color:var(--sky);font-size:2rem;">Tracking Report - Account ID: {account_id}</h1>
<!-- KPIs -->
<div class="kpi-grid">
  <div class="kpi"><div class="label">Total Checked</div><div class="value">{total}</div></div>
  <div class="kpi"><div class="label">Fraud Score > 90</div><div class="value">{fraud_90}</div></div>
  <div class="kpi"><div class="label">Flagged as Spammer</div><div class="value">{spammer}</div></div>
  <div class="kpi"><div class="label">Flagged as Leaked</div><div class="value">{leaked}</div></div>
  <div class="kpi"><div class="label">Posted to CTM</div><div class="value">{posted}</div></div>
</div>
<div class="card">
  <h2>Results by Tracking Number</h2>
  <table>
    <tr>
      <th>Number</th>
      <th>Fraud Score</th>
      <th>Spammer</th>
      <th>Leaked</th>
      <th>Risky</th>
      <th>Checked</th>
      <th>Posted</th>
      <th>Response Status</th>
    </tr>
'''.format(total=total, fraud_90=fraud_90, spammer=spammer, leaked=leaked, posted=posted, account_id=account_id)

    #-- Table Rows
    for r in results:
        html += "<tr>"
        html += f"<td>{r.get('number','')}</td>"
        fs = r.get('fraud_score','')
        html += f"<td>{fs if fs is not None else ''}{' <span class=\"flag-yes\">⚠</span>' if (fs and fs > 90) else ''}</td>"
        html += "<td class='{}'>{}</td>".format('flag-yes' if r.get('spammer') else 'flag-no', 'Yes' if r.get('spammer') else 'No')
        html += "<td class='{}'>{}</td>".format('flag-yes' if r.get('leaked') else 'flag-no', 'Yes' if r.get('leaked') else 'No')
        html += "<td class='{}'>{}</td>".format('flag-yes' if r.get('risky') else 'flag-no', 'Yes' if r.get('risky') else 'No')
        html += f"<td>{r.get('checked_datetime','')}</td>"
        html += "<td class='{}'>{}</td>".format('status-yes' if r.get('posted_to_ctm') else 'status-no',
                                                 'Yes' if r.get('posted_to_ctm') else 'No')
        html += "<td>{}</td>".format(r.get('status_code') if r.get('status_code') is not None else '')
        html += "</tr>\n"

    html += '''
  </table>
</div>
</div>
</body>
</html>
'''
    with open(output_file, "w") as f:
        f.write(html)
    import subprocess
    subprocess.run(['open', output_file])

def main():
    print("--- CTM/IPQS Bulk Phone Check Tool ---\n")
    override_24h = '--override-24h' in sys.argv
    config = load_or_prompt_config()
    last_checked = load_last_checked()
    post_log = load_post_log()

    base_ctm_url = f"https://api.calltrackingmetrics.com/api/v1/accounts/{config['CTM_ACCOUNT_ID']}"
    numbers_url = f"{base_ctm_url}/numbers"
    headers = {'Content-Type': 'application/json'}

    try:
        ctm_resp = requests.get(
            numbers_url, headers=headers,
            auth=HTTPBasicAuth(config['CTM_ACCESS_KEY'], config['CTM_SECRET_KEY']), timeout=30
        )
        ctm_resp.raise_for_status()
        ctm_data = ctm_resp.json()
    except Exception as e:
        print(f"Error fetching tracking numbers from CTM: {e}")
        return

    with open('tracking_numbers.json', 'w') as f:
        json.dump(ctm_data, f, indent=2)

    number_id_map = {n['number']: n['id'] for n in ctm_data.get('numbers', []) if 'number' in n and 'id' in n}
    numbers = list(number_id_map.keys())
    print(f"Found {len(numbers)} phone numbers.")

    os.makedirs('ipqs_results', exist_ok=True)

    checked, skipped, errors, posted = [], [], [], []
    risky_numbers, fraud_numbers, spam_numbers = [], [], []
    html_results = []

    for num in numbers:
        last_time = last_checked.get(num)
        ipqs_filename = os.path.join('ipqs_results', f'ipqs_{num}.json')
        checked_datetime = None
        check_new_ipqs = (override_24h or not last_time or is_over_24_hours_ago(last_time))

        ipqs_json = None
        ipqs_fraud_score, ipqs_spammer, ipqs_leaked, ipqs_risky = None, None, None, None

        if check_new_ipqs:
            checked_datetime = datetime.now(UTC).strftime('%Y-%m-%d %H:%M')
            last_checked[num] = checked_datetime
            ipqs_url = f"https://www.ipqualityscore.com/api/json/phone/{config['IPQS_API_KEY']}/{num}?strictness=0"
            try:
                resp = requests.get(ipqs_url, timeout=30)
                ipqs_json = resp.json()
                with open(ipqs_filename, 'w') as f:
                    json.dump(ipqs_json, f, indent=2)
                print(f"Checked {num}, result saved to {ipqs_filename}")
                checked.append(num)
            except Exception as e:
                print(f"Error checking {num} with IPQualityScore: {e}")
                errors.append(num)
                continue
        else:
            checked_datetime = last_time
            print(f"Skipping new IPQS check for {num} (last checked at {last_time})")
            skipped.append(num)
        if not ipqs_json and os.path.exists(ipqs_filename):
            try:
                with open(ipqs_filename, 'r') as f:
                    ipqs_json = json.load(f)
            except Exception as e:
                print(f"Could not load IPQS result for {num}: {e}")
                errors.append(num)
                continue
        elif not ipqs_json:
            print(f"No IPQS data available for {num}, skipping POST.")
            errors.append(num)
            continue

        ipqs_fraud_score = ipqs_json.get('fraud_score')
        ipqs_spammer    = bool(ipqs_json.get('spammer', False))
        ipqs_leaked     = bool(ipqs_json.get('leaked', False))
        ipqs_risky      = bool(ipqs_json.get('risky', False))

        payload_dict = build_ctm_update_payload(ipqs_json, checked_datetime)
        payload = {"custom_fields": payload_dict}
        tpn_id = number_id_map[num]
        update_url = f"{base_ctm_url}/numbers/{tpn_id}/update_number"
        post_status = None
        try:
            update_resp = requests.post(
                update_url, headers=headers,
                auth=HTTPBasicAuth(config['CTM_ACCESS_KEY'], config['CTM_SECRET_KEY']),
                json=payload, timeout=30
            )
            log_entry = {
                'number': num,
                'ctm_id': tpn_id,
                'payload': payload,
                'status_code': update_resp.status_code,
                'response_text': update_resp.text,
                'timestamp': datetime.now(UTC).strftime('%Y-%m-%d %H:%M:%S')
            }
            post_log[num] = log_entry
            post_status = update_resp.status_code
            if 200 <= update_resp.status_code < 300:
                print(f"Posted results to CTM for {num} (status {update_resp.status_code}).")
            else:
                print(f"Error posting to CTM for {num} (status={update_resp.status_code}): {update_resp.text}")
                errors.append(num)
            posted.append(num)
        except Exception as e:
            print(f"Exception posting to CTM for {num}: {e}")
            errors.append(num)

        if payload_dict.get('TN_flagged_as_risky'):
            risky_numbers.append(num)
        if payload_dict.get('TN_Fraud_Score_over_90'):
            fraud_numbers.append(num)
        if payload_dict.get('TN_flagged_as_spammer'):
            spam_numbers.append(num)

        html_results.append({
            'number': num,
            'fraud_score': ipqs_fraud_score,
            'spammer': ipqs_spammer,
            'leaked': ipqs_leaked,
            'risky': ipqs_risky,
            'checked_datetime': checked_datetime,
            'posted_to_ctm': (num in posted),
            'status_code': post_status,
        })

    save_last_checked(last_checked)
    save_post_log(post_log)

    print("\n--- Summary ---")
    print(f"Checked IPQS for {len(checked)} number(s) this run.")
    if checked:
        print("Numbers checked:")
        for n in checked:
            print(f"  {n}")
    print(f"Skipped IPQS check for {len(skipped)} number(s) (checked less than 24 hours ago).")
    if skipped:
        print("Numbers skipped:")
        for n in skipped:
            print(f"  {n}")
    print(f"Posted to CTM for {len(posted)} number(s).")
    if risky_numbers:
        print(f"\nFlagged as RISKY ({len(risky_numbers)}):")
        for n in risky_numbers:
            print(f"  {n}")
    if fraud_numbers:
        print(f"\nFlagged as FRAUDULENT (score > 90) ({len(fraud_numbers)}):")
        for n in fraud_numbers:
            print(f"  {n}")
    if spam_numbers:
        print(f"\nFlagged as SPAMMER ({len(spam_numbers)}):")
        for n in spam_numbers:
            print(f"  {n}")
    if errors:
        print(f"\nErrors occurred for {len(errors)} number(s):")
        for n in errors:
            print(f"  {n}")
    print("\nDone!")

    # NEW: Write HTML output
    write_html_report(html_results, config['CTM_ACCOUNT_ID'], output_file="tracking_check_output.html")

if __name__ == '__main__':
    main()
